import json
import os
import csv
from typing import Set
from collections import defaultdict

pred_root = "./pred_results"
output_csv = "./p_r_f_all_mm_with_match.csv"

os.makedirs(os.path.dirname(output_csv), exist_ok=True)

applications = ["petclinic","pos", "jforum"]
methods = ["magnet_class","cargo_class","micromatic", "topic","bert","gpt"]

gt_paths = {
    "petclinic_class_n": "./ground_truth/microm_ground/gt_petclinic_class_n.json",
    "pos_class_n": "./ground_truth/microm_ground/gt_pos_class_n.json",
    "jforum_class_n": "./ground_truth/microm_ground/gt_jforum_class_n.json"
    
}

def flatten_clusters(services, is_microservice=False):
    flattened = []
    if is_microservice:
        for microservice in services['microservices']:
            cluster_set = set()
            for service_type, service_groups in microservice['microservice'].items():
                for service_group in service_groups:
                    cluster_set.update([service['className'] for service in service_group['service']])
            flattened.append(cluster_set)
    else:
        for service_groups in services.values():
            for service_group in service_groups:
                cluster_set = set(service['className'] for service in service_group['service'])
                flattened.append(cluster_set)
    return flattened

def calculate_overlap(set1, set2): # set1(a,b) set2(a,b,c) intersection(a,b) size 2 , biger size 3 2/3=000
    intersection = len(set1.intersection(set2))
    bigger_set_size = max(len(set1), len(set2))
    return intersection / bigger_set_size if bigger_set_size > 0 else 0

def evaluate_microservice_clustering(results, ground_truth_path, threshold=0.5):
    with open(ground_truth_path, 'r') as f:
        ground_truths = json.load(f)

    predicted_clusters = flatten_clusters(results, is_microservice=True)

    #flatten predicted 
    predicted_classes = set()
    for cluster in predicted_clusters:
        predicted_classes.update(cluster)

    
    ground_truth_clusters = [] # pred {a,b},{c} gt:{x,a},{b,c} gt will be {a},{b,c}
    for cluster in ground_truths:
        normed = set(cluster)   
        filtered = normed.intersection(predicted_classes)
        if filtered:  
            ground_truth_clusters.append(filtered)
    TP = FP = FN = 0

    for result_cluster in predicted_clusters:
        overlaps = [calculate_overlap(result_cluster, gt_cluster) for gt_cluster in ground_truth_clusters]
        best_overlap = max(overlaps) if overlaps else 0
        if best_overlap >= threshold:
            TP += 1
        else:
            FP += 1

    for gt_cluster in ground_truth_clusters:
        overlaps = [calculate_overlap(gt_cluster, result_cluster) for result_cluster in predicted_clusters]
        best_overlap = max(overlaps) if overlaps else 0
        if best_overlap < threshold:
            FN += 1

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

    return precision, recall, f1

with open(output_csv, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(["Application", "Method", "Precision", "Recall", "F1-Score"])

    for app in applications:
        for method in methods:
            
            # if method in ["magnet","cargo"]:
            #     gt_key = f"{app}_method"
            # else:
            gt_key = f"{app}_class_n"
            gt_path = gt_paths[gt_key]

            pred_path = os.path.join(pred_root, method, f"{app}.json")

            if not os.path.exists(pred_path):
                print(f"missing prediction file: {pred_path}")
                writer.writerow([app, method, "missing", "missing", "missing"])
                continue

            try:
                with open(pred_path, 'r') as f:
                    result_data = json.load(f)
               
                precision, recall, f1 = evaluate_microservice_clustering(result_data, gt_path, threshold=0.50)
                writer.writerow([app, method, f"{precision:.4f}", f"{recall:.4f}", f"{f1:.4f}"])
                print(f"{app}-{method}: P={precision:.4f}, R={recall:.4f}, F1={f1:.4f}")

            except Exception as e:
                print(f"error evaluating {app} - {method}: {e}")
                writer.writerow([app, method, "error", "error", "error"])

